/**
 * Package for storing reusable view
 */
package com.ajax.restapiproject.view;