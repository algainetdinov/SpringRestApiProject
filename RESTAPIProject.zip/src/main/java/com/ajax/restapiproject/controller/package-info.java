/**
 * Stores app-wide controllers
 */
package com.ajax.restapiproject.controller;