/**
 * Package for storing Application and Config classes
 */
package com.ajax.restapiproject;