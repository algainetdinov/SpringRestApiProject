/**
 * Package for storing views of office
 */
package com.ajax.restapiproject.office.view;