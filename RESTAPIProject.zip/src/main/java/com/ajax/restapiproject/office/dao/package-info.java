/**
 * Stores organization dao
 */
package com.ajax.restapiproject.office.dao;