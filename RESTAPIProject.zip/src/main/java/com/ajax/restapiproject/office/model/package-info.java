/**
 * Package for storing office model
 */
package com.ajax.restapiproject.office.model;