/**
 * Stores office service classes
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.office.service;