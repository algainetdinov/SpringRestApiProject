package com.ajax.restapiproject.office.service;

import org.springframework.stereotype.Component;

import com.ajax.restapiproject.service.LegalEntityValidation;

/**
 * Office validation
 * @author Al
 *
 */
@Component
public class OfficeValidation extends LegalEntityValidation {
}
