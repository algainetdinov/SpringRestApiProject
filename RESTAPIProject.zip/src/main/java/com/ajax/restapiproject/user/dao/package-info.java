/**
 * Stores user DAO 
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.user.dao;