/**
 * Package for storing user controller
 */
package com.ajax.restapiproject.user.controller;