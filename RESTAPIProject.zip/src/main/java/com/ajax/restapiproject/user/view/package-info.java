/**
 * Package for storing user view
 */
package com.ajax.restapiproject.user.view;