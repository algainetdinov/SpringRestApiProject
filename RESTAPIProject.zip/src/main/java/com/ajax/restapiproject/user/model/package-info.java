/**
 * Package for storing user model
 */
package com.ajax.restapiproject.user.model;