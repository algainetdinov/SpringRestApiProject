/**
 * Stores user service
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.user.service;