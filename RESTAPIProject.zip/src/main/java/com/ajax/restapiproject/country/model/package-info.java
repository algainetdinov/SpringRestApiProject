/**
 * Package for storing country model
 */
package com.ajax.restapiproject.country.model;