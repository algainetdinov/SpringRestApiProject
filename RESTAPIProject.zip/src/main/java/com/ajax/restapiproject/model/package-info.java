/**
 * Package for storing superclass models
 */
package com.ajax.restapiproject.model;