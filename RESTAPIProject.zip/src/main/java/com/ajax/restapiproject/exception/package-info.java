/**
 * Stores exception types 
 */
package com.ajax.restapiproject.exception;