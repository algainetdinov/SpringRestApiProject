/**
 * Stores doctype DAO
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.doctype.dao;