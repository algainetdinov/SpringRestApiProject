/**
 * Package for storing document type controller
 */
package com.ajax.restapiproject.doctype.controller;