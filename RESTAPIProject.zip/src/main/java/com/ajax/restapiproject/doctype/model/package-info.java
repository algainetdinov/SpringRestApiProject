/**
 * Package for storing document type model
 */
package com.ajax.restapiproject.doctype.model;