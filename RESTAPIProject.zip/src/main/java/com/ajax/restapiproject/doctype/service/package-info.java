/**
 * Stores Doctype service
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.doctype.service;