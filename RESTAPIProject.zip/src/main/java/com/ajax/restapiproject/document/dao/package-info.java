/**
 * Holds document DAO
 */
/**
 * @author Al
 *
 */
package com.ajax.restapiproject.document.dao;