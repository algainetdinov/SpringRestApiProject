/**
 * Package for storing document model
 */
package com.ajax.restapiproject.document.model;