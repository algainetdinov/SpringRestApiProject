/**
 * Stores organization dao
 */
package com.ajax.restapiproject.organization.dao;