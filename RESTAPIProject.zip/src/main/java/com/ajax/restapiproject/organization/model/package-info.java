/**
 * Package for storing organization model
 */
package com.ajax.restapiproject.organization.model;