/**
 * Stores organization relateted service
 */
package com.ajax.restapiproject.organization.service;