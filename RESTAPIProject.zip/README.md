Project for creating REST service application
======================
Репозиторий
-
git - https://github.com/algainetdinov/SpringRestApiProject

Использовать Swagger UI
-
Пример обращения http://localhost:8888//swagger-ui.html